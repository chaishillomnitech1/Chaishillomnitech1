# Prototypes
This directory contains initial versions and drafts of various projects and ideas in development.